# Portfolio contact backend with email OTP verification

This starter connects the portfolio contact form to a secure Node.js API. It uses:

- **Node.js + Express** for the API
- **Resend** to send OTP emails and verified contact notifications
- **Upstash Redis** for short-lived OTPs, cooldowns, verification tokens, and rate limits

The frontend never receives provider credentials. OTPs are generated on the server, stored as HMAC hashes, expire after five minutes, and allow at most five verification attempts. Successful verification creates a random, short-lived, single-use token. The backend consumes that token before sending the contact message.

## 1. Create the required services

1. Create a Resend account and verify a domain you control. Resend generally requires a verified sending domain for production delivery. Create an API key.
2. Create an Upstash Redis database and copy its REST URL and REST token.
3. Decide the exact public origin of your portfolio, e.g. `https://your-domain.example`.

You must own or control the domain used in `MAIL_FROM`. Do not use a made-up sender address. `OWNER_EMAIL` can be your Gmail inbox.

## 2. Configure the backend

Use Node.js 20 or newer. In this folder:

```bash
npm install
cp .env.example .env
```

Fill `.env` with your real values:

- `ALLOWED_ORIGINS`: exact frontend origin(s), comma-separated, without trailing slash
- `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN`: from Upstash
- `RESEND_API_KEY`: from Resend
- `MAIL_FROM`: a sender on your verified Resend domain, e.g. `Portfolio Contact <contact@your-domain.example>`
- `OWNER_EMAIL`: the Gmail address that should receive contact messages
- `OTP_HMAC_SECRET`: a long random secret (32+ characters). Generate one with `openssl rand -hex 32`.

Run locally:

```bash
npm run dev
```

Health check: `http://localhost:3000/api/health`.

## 3. Deploy the backend

Deploy this folder as a Node web service on a provider such as Render, Railway, or another Node host. Set the build command to `npm install`, start command to `npm start`, and add every `.env` variable in the host's secret/environment settings. Do not upload `.env` to Git or share it publicly.

After deployment, copy the public API base URL, e.g. `https://your-api-host.example`.

## 4. Connect the frontend

Open the supplied `portfolio_with_otp.html`. At the beginning of its contact-form script, set:

```js
const API_BASE_URL = "https://your-api-host.example";
```

For same-origin hosting, use an empty string: `const API_BASE_URL = "";`.

Set `ALLOWED_ORIGINS` on the backend to the exact deployed portfolio origin. If you use both a production domain and a preview domain, list each exact origin separated by commas.

## 5. API routes

- `POST /api/otp/request` — body `{ "email": "visitor@example.com", "botcheck": "" }`
- `POST /api/otp/verify` — body `{ "email": "visitor@example.com", "code": "123456" }`
- `POST /api/contact` — body `{ "name": "Visitor", "email": "visitor@example.com", "projectType": "Website", "message": "...", "verificationToken": "...", "botcheck": "" }`

The OTP request response is deliberately generic. This confirms only that the code was sent to an address that can receive mail; it does not prove a person's identity or guarantee that an inbox will always remain active.

## Security and production notes

- Keep `.env`, Resend keys, Upstash tokens, and `OTP_HMAC_SECRET` on the backend only.
- Use HTTPS for the portfolio and API.
- Keep `ALLOWED_ORIGINS` restrictive; do not use `*`.
- Configure Resend SPF/DKIM/domain authentication as instructed in its dashboard.
- Review provider quotas, retention, privacy terms, and billing before launch.
- The rate limiter uses Upstash Redis, so limits work across server instances.
- For production, add monitoring/alerts and a privacy notice explaining that email addresses and messages are processed by your chosen providers.
- The browser-side form is not a security boundary; all validation and verification are repeated by the backend.

This starter has not been connected to live Resend/Upstash accounts or deployed. Live OTP delivery and inbox delivery must be tested after you add your own credentials and verified sending domain.

import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { z } from 'zod';
import { randomInt, randomBytes, createHmac, timingSafeEqual } from 'node:crypto';
import { Redis } from '@upstash/redis';
import { Ratelimit } from '@upstash/ratelimit';
import { Resend } from 'resend';

const required = [
  'UPSTASH_REDIS_REST_URL', 'UPSTASH_REDIS_REST_TOKEN', 'RESEND_API_KEY',
  'MAIL_FROM', 'OWNER_EMAIL', 'OTP_HMAC_SECRET'
];
const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`Missing required environment variables: ${missing.join(', ')}`);
  process.exit(1);
}
if (process.env.OTP_HMAC_SECRET.length < 32) {
  console.error('OTP_HMAC_SECRET must be at least 32 characters long.');
  process.exit(1);
}

const app = express();
const redis = Redis.fromEnv();
const resend = new Resend(process.env.RESEND_API_KEY);
const PORT = Number(process.env.PORT || 3000);
const OTP_TTL_SECONDS = 5 * 60;
const VERIFIED_TTL_SECONDS = 10 * 60;
const RESEND_COOLDOWN_SECONDS = 60;
const MAX_OTP_ATTEMPTS = 5;
const otpLimiter = new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(3, '15 m'), prefix: 'rl:otp' });
const verifyLimiter = new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(10, '15 m'), prefix: 'rl:verify' });
const contactLimiter = new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(5, '1 h'), prefix: 'rl:contact' });

const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error('Origin not allowed'));
  },
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type']
}));
app.use(express.json({ limit: '12kb' }));

const emailSchema = z.string().trim().email().max(254).transform(v => v.toLowerCase());
const requestSchema = z.object({ email: emailSchema, botcheck: z.string().max(200).optional().default('') });
const verifySchema = z.object({ email: emailSchema, code: z.string().regex(/^\d{6}$/) });
const contactSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: emailSchema,
  projectType: z.string().trim().max(80).default('Something else'),
  message: z.string().trim().min(10).max(5000),
  verificationToken: z.string().min(40).max(200),
  botcheck: z.string().max(200).optional().default('')
});

const hash = (value) => createHmac('sha256', process.env.OTP_HMAC_SECRET).update(value).digest('hex');
const safeEqual = (a, b) => {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && timingSafeEqual(aa, bb);
};
const cleanHeader = (value) => value.replace(/[\r\n]/g, ' ').slice(0, 180);
const rateLimit = async (limiter, id, res) => {
  const result = await limiter.limit(id);
  if (result.success) return true;
  res.set('Retry-After', String(Math.max(1, Math.ceil((result.reset - Date.now()) / 1000))));
  res.status(429).json({ error: 'Too many requests. Please wait and try again.' });
  return false;
};

app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

app.post('/api/otp/request', async (req, res, next) => {
  try {
    const parsed = requestSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Enter a valid email address.' });
    const { email, botcheck } = parsed.data;
    // Honeypot: respond generically so bots do not learn that they were detected.
    if (botcheck) return res.status(202).json({ message: 'If the address can receive email, a code will be sent.' });
    const ip = req.ip || 'unknown';
    if (!(await rateLimit(otpLimiter, `${ip}:${email}`, res))) return;

    const cooldownKey = `otp:cooldown:${hash(email)}`;
    const coolingDown = await redis.get(cooldownKey);
    if (coolingDown) return res.status(429).json({ error: 'Please wait before requesting another code.' });

    const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
    await redis.set(`otp:data:${hash(email)}`, JSON.stringify({ codeHash: hash(`${email}:${code}`), attempts: 0 }), { ex: OTP_TTL_SECONDS });
    await redis.set(cooldownKey, '1', { ex: RESEND_COOLDOWN_SECONDS });

    const { error } = await resend.emails.send({
      from: process.env.MAIL_FROM,
      to: [email],
      subject: 'Your portfolio contact verification code',
      text: `Your verification code is ${code}. It expires in 5 minutes. If you did not request this, you can ignore this email.`,
      html: `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:24px"><h2>Verify your email</h2><p>Use this one-time code to verify your email address:</p><p style="font-size:32px;font-weight:700;letter-spacing:8px">${code}</p><p>This code expires in 5 minutes. If you did not request it, ignore this message.</p></div>`
    });
    if (error) {
      await redis.del(`otp:data:${hash(email)}`);
      await redis.del(cooldownKey);
      console.error('OTP email provider error:', error);
      return res.status(502).json({ error: 'Unable to send the verification email right now. Please try again later.' });
    }
    return res.status(200).json({ message: 'If the address can receive email, a verification code has been sent.' });
  } catch (error) { next(error); }
});

app.post('/api/otp/verify', async (req, res, next) => {
  try {
    const parsed = verifySchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Enter the six-digit code.' });
    const { email, code } = parsed.data;
    if (!(await rateLimit(verifyLimiter, `${req.ip || 'unknown'}:${email}`, res))) return;
    const key = `otp:data:${hash(email)}`;
    const stored = await redis.get(key);
    if (!stored) return res.status(400).json({ error: 'That code has expired or was not requested. Request a new one.' });
    const record = typeof stored === 'string' ? JSON.parse(stored) : stored;
    if (record.attempts >= MAX_OTP_ATTEMPTS) {
      await redis.del(key);
      return res.status(429).json({ error: 'Too many incorrect attempts. Request a new code.' });
    }
    const candidate = hash(`${email}:${code}`);
    if (!safeEqual(candidate, record.codeHash)) {
      record.attempts += 1;
      const ttl = await redis.ttl(key);
      if (ttl > 0) await redis.set(key, JSON.stringify(record), { ex: ttl });
      return res.status(400).json({ error: `Incorrect code. ${MAX_OTP_ATTEMPTS - record.attempts} attempt(s) remaining.` });
    }

    await redis.del(key);
    const token = randomBytes(32).toString('base64url');
    await redis.set(`verified:${hash(token)}`, email, { ex: VERIFIED_TTL_SECONDS });
    return res.json({ message: 'Email verified.', verificationToken: token, expiresIn: VERIFIED_TTL_SECONDS });
  } catch (error) { next(error); }
});

app.post('/api/contact', async (req, res, next) => {
  try {
    const parsed = contactSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Please check your contact form and try again.' });
    const { name, email, projectType, message, verificationToken, botcheck } = parsed.data;
    if (botcheck) return res.status(202).json({ message: 'Your message has been received.' });
    if (!(await rateLimit(contactLimiter, req.ip || 'unknown', res))) return;

    const tokenKey = `verified:${hash(verificationToken)}`;
    // Atomically consume the token so it cannot be reused or submitted twice.
    const consumedEmail = await redis.eval(
      "local v = redis.call('GET', KEYS[1]); if v == ARGV[1] then redis.call('DEL', KEYS[1]); return v else return nil end",
      [tokenKey], [email]
    );
    if (!consumedEmail) return res.status(403).json({ error: 'Please verify this email address again before sending your message.' });

    const safeName = cleanHeader(name);
    const safeProject = cleanHeader(projectType);
    const { error } = await resend.emails.send({
      from: process.env.MAIL_FROM,
      to: [process.env.OWNER_EMAIL],
      replyTo: email,
      subject: `Portfolio contact: ${safeProject}`,
      text: `New verified portfolio contact\n\nName: ${safeName}\nEmail: ${email}\nProject type: ${safeProject}\n\nMessage:\n${message}`
    });
    if (error) {
      console.error('Contact email provider error:', error);
      return res.status(502).json({ error: 'Your email was verified, but the message could not be delivered. Please try again.' });
    }
    return res.json({ message: 'Your message has been sent successfully.' });
  } catch (error) { next(error); }
});

app.use((err, _req, res, _next) => {
  console.error('API error:', err?.message || err);
  if (err?.message === 'Origin not allowed') return res.status(403).json({ error: 'This website is not allowed to use the contact service.' });
  return res.status(500).json({ error: 'Something went wrong. Please try again later.' });
});

app.listen(PORT, () => console.log(`Portfolio contact API listening on port ${PORT}`));
